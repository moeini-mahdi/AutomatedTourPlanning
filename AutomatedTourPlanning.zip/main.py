from flask import Flask
from flask import render_template
from flask import request
import requests
import json
import mysql.connector
from routing import getRoutes, getRoutesHeuristic
import folium
import openrouteservice
from openrouteservice import client,directions

app = Flask(__name__)

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

#customer
@app.route("/customers")
def getCustomers():
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM customers")

    res = cursor.fetchall()
    
    cursor.close()
    cnx.close()

    return render_template('customers.html', customers=res)

@app.route("/calculation")
def calculation():
    return render_template('calculation.html')

@app.route("/calculationHeuristic")
def calculationHeuristic():
    return render_template('calculationHeuristic.html')

@app.route("/customer/<id>")
def getCustomer(id):
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM customers WHERE id="+str(id))

    res = cursor.fetchone()

    cursor.close()
    cnx.close()

    return render_template('customer.html', customer=res)

@app.route("/customer/save", methods=['POST'])
def saveCustomer():
    id = request.form['id']
    name = request.form['name']
    address = request.form['address']
    comment = request.form['comment']

    #maybe it makes more sense to only ask for querying the geodata if there is a change in address

     #call openrouteservice to get geodata
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    geo = requests.get('https://api.openrouteservice.org/geocode/search?api_key='+api_key+'&text='+str(address))
    json_data = json.loads(geo.text)
    longitude = json_data['features'][0]['geometry']['coordinates'][0]
    latitude = json_data['features'][0]['geometry']['coordinates'][1]

    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("UPDATE customers SET name='"+str(name)+"', address='"+str(address)+"', longitude='"+str(longitude)+"', latitude='"+str(latitude)+"', comment='"+str(comment)+"' WHERE id="+str(id))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    return getCustomers();

@app.route("/customer/add")
def addCustomer():
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT id FROM customers")

    res = cursor.fetchall()
    biggestId = max(res)
    nextId = biggestId[0] +1

    cursor.execute("INSERT INTO customers (id) VALUES ('"+str(nextId)+"')")
    cnx.commit()
    cursor.close()
    cnx.close()
   
    return render_template('customer.html',customer=[nextId])

@app.route("/customer/delete/<id>")
def deleteCustomer(id):
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()

    cursor.execute("DELETE FROM customers WHERE id="+str(id))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    return getCustomers()

@app.route("/customer/check/<id>")
def checkCustomer(id):
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()

    cursor.execute("SELECT active FROM customers WHERE id="+str(id))
    res = cursor.fetchone()
    
    if res[0]==1:
        res = 0
    else:
        res = 1

    cursor.execute("UPDATE customers SET active="+str(res)+" WHERE id="+str(id))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    return getCustomers()

#employees
@app.route("/employees")
def getEmployees():
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM employees")

    res = cursor.fetchall()
    
    cursor.close()
    cnx.close()

    return render_template('employees.html', employees=res)

@app.route("/employee/<id>")
def getEmployee(id):
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM employees WHERE id="+str(id))

    res = cursor.fetchone()

    cursor.close()
    cnx.close()

    return render_template('employee.html', employee=res)

@app.route("/employee/save", methods=['POST'])
def saveEmployee():
    id = request.form['id']
    name = request.form['name']
    address = request.form['address']
    comment = request.form['comment']
    
    #call openrouteservice to get geodata
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    geo = requests.get('https://api.openrouteservice.org/geocode/search?api_key='+api_key+'&text='+str(address))
    json_data = json.loads(geo.text)
    longitude = json_data['features'][0]['geometry']['coordinates'][0]
    latitude = json_data['features'][0]['geometry']['coordinates'][1]

    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("UPDATE employees SET name='"+str(name)+"', address='"+str(address)+"', longitude='"+str(longitude)+"', latitude='"+str(latitude)+"', comment='"+str(comment)+"' WHERE id="+str(id))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    return getEmployees();

@app.route("/employee/add")
def addEmployee():
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    cursor.execute("SELECT id FROM employees")

    res = cursor.fetchall()
    biggestId = max(res)
    nextId = biggestId[0] +1

    cursor.execute("INSERT INTO employees (id) VALUES ('"+str(nextId)+"')")
    cnx.commit()
    cursor.close()
    cnx.close()
   
    return render_template('employee.html',employee=[nextId]) 

@app.route("/employee/delete/<id>")
def deleteEmployee(id):
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()

    cursor.execute("DELETE FROM employees WHERE id="+str(id))
    cnx.commit()

    cursor.close()
    cnx.close()
    
    return getEmployees()

@app.route("/calcRoute")
def calcRoute():
    
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    # the openrouteservice api wants long,lat, google Maps for example uses lat,long
    cursor.execute("SELECT * FROM customers")

    res = cursor.fetchall()

    cursor.close()
    cnx.close()

    children = []
    for child in res:
        children.append({"id":child[0],"name":child[1],"address":child[2],"geo":(child[3],child[4])})

    #print("children: ",children)
    #add fixed KITA location
    children.append({"id":0,"name":"KITA","address":"Depot","geo":(7.54913,49.39845)})

    geodata=[]
    for child in children:
        geodata.append(child["geo"])
    #make api call to retrieve time distance matrix
    url = 'https://api.openrouteservice.org/v2/matrix/driving-car'
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    headers = {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': api_key,
        'Content-Type': 'application/json; charset=utf-8'
    }
    #payload = {"locations":res, "destinations":[len(res)-1]}
    payload = {"locations":geodata}
    
    geo = requests.post(url, json=payload, headers=headers)
    json_response = json.loads(geo.text)

    durations= json_response["durations"]
    
    distances={}
    i=-1
    k=-1


    #todo build new distancematrix with id instead of lat/long

    for vertical in children:
        i=i+1
        k=-1
        for horizontal in children:
            k=k+1
            distances.update({(vertical["id"],horizontal["id"]):durations[i][k]})
       
    
    print("distances: ",distances)

    results=getRoutes(children,distances)

    return render_template('calculation.html',tours=results)

@app.route("/calcRouteHeuristic", methods=['POST'])
def calcRouteHeuristic():
    vehicleCapacity = int(request.form['capacity'])
    
    return actuallyCalc(vehicleCapacity)

def actuallyCalc(vehicleCapacity):
    
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    # the openrouteservice api wants long,lat, google Maps for example uses lat,long
    cursor.execute("SELECT * FROM customers")

    res = cursor.fetchall()

    cursor.close()
    cnx.close()

    children = []
    for child in res:
        children.append({"id":child[0],"name":child[1],"address":child[2],"geo":(child[3],child[4])})

    #print("children: ",children)
    #add fixed KITA location
    children.append({"id":0,"name":"KITA","address":"Depot","geo":(7.54913,49.39845)})

    geodata=[]
    for child in children:
        geodata.append(child["geo"])
    #make api call to retrieve time distance matrix
    url = 'https://api.openrouteservice.org/v2/matrix/driving-car'
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    headers = {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': api_key,
        'Content-Type': 'application/json; charset=utf-8'
    }
    #payload = {"locations":res, "destinations":[len(res)-1]}
    payload = {"locations":geodata}
    
    geo = requests.post(url, json=payload, headers=headers)
    json_response = json.loads(geo.text)

    durations= json_response["durations"]
    
    distances={}
    i=-1
    k=-1


    #todo build new distancematrix with id instead of lat/long

    for vertical in children:
        i=i+1
        k=-1
        for horizontal in children:
            k=k+1
            distances.update({(vertical["id"],horizontal["id"]):durations[i][k]})
       
    
    results=getRoutesHeuristic(children,distances,vehicleCapacity)

    #TODO: take the resulting tours and for each, create a directions API request and put that into folium to create a map

    client = openrouteservice.Client(key='5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792')

    i=0
    print("main.py results ",results)
    for tour in results:
        if len(tour["pickups"]) > 1:
            coords = ()
            for stop in tour["pickups"]:
                coords = coords + ((stop["geo"][0],stop["geo"][1]),)
                 

            request = {'coordinates': coords,
                'profile': 'driving-car',
                'geometry': 'true',
                'format_out': 'geojson'    
                }

            routes = client.directions(**request)
            map = folium.Map(location=[coords[0][1],coords[0][0]],zoom_start=10)
            folium.features.GeoJson(routes, style_function = lambda x:{'color':'black','weight':3}).add_to(map)

            try:
                totalDistance = routes['features'][0]['properties']['summary']['distance']
                totalDuration = routes['features'][0]['properties']['summary']['duration']
            except KeyError:
                pass


            #add depot to tour start
            coords = ((7.54913,49.39845),(tour["pickups"][0]["geo"][0],tour["pickups"][0]["geo"][1]))

            
            request = {'coordinates': coords,
                'profile': 'driving-car',
                'geometry': 'true',
                'format_out': 'geojson'    
                }
            route = client.directions(**request)

            folium.features.GeoJson(route, style_function = lambda x:{'color':'black','weight':2,'dashArray':'4'}).add_to(map)

            try:
                totalDistance = totalDistance + route['features'][0]['properties']['summary']['distance']
                totalDuration = totalDuration + route['features'][0]['properties']['summary']['duration']
            except KeyError:
                pass


            #add driver to tour end 
            nrPickups = len(tour["pickups"])-1
            coords = ((tour["pickups"][nrPickups]["geo"][0],tour["pickups"][nrPickups]["geo"][1]),(tour["driver"]["geo"][0],tour["driver"]["geo"][1]))

            
            request = {'coordinates': coords,
                'profile': 'driving-car',
                'geometry': 'true',
                'format_out': 'geojson'    
                }
            route = client.directions(**request)
            
            folium.features.GeoJson(route, style_function = lambda x:{'color':'#e60005','weight':2,'dashArray':'4'}).add_to(map)

            stopcount= 1
            for stop in tour["pickups"]:
                folium.Marker(location=[stop["geo"][1],stop["geo"][0]],icon=folium.Icon(color='#e60005'),tooltip="<b>"+stop["name"]+"</b><br>"+stop["address"]).add_to(map)
                stopcount = stopcount + 1

            print("route driver end: \n", route)

            try:
                totalDistance = totalDistance + route['features'][0]['properties']['summary']['distance']
                totalDuration = totalDuration + route['features'][0]['properties']['summary']['duration']
            except KeyError:
                pass

            map.save("templates/maps/map"+str(i)+".html")
            i=i+1
        
        tour['distance'] = round(totalDistance/1000,1)
        m, s = divmod(totalDuration, 60)
        h, m = divmod(m, 60)
        tour['duration'] = str(round(h))+":"+str(round(m))+":"+str(round(s))
            

    return render_template('calculationHeuristic.html',tours=results)