/*
TODO:
when clicking the checkbox in the list view, change DB and change checked classes too
*/

$(document).ready(function(){

    $(".active").click(function(event){
        id = event.target.id;
        $.get("/customer/check/"+id);
      });
  
  });
