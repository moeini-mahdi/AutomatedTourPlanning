from configparser import Error
from gurobipy import Model, GRB, quicksum
import mysql.connector
import requests
import json


#helper globals
new = ()
routes = []
capacity = 0

def getRoutes(nodes,distances):

    #nodes come as [{"id":X,"name":"abc...",...},...]
    V=nodes
    
    
    # I only contains the customers, not the destination
    new_nodes = nodes.copy()
    new_nodes.pop()
    I=new_nodes
    
    A = [(i, j) for i in V for j in V if i != j]
    
    #d = {(i, j): np.hypot(xc[i]-xc[j], yc[i]-yc[j]) for i, j in A}
    # distances: {(node_ID,node_ID): distance,...}
    d = distances

    #Number of customers
    n = len(I)

    #kita node
    kita={"id":0,"name":"KITA","address":"Depot","geo":(7.54913,49.39845)}

    #add dummy node n+1
    dummyNode = {"id":9999,"name":"dummy","address":None,"geo":None}
    V_new = V + [dummyNode]
    #add arcs to dummy node for all nodes in V
    A_add = [(i,dummyNode) for i in V_new if i != dummyNode]
    A_add_more = [(dummyNode,i) for i in V_new if dummyNode != i]

    A_new = A + A_add + A_add_more
    #reassign distance values
    d_add = {(i["id"], j["id"]): 0 for i, j in A_add}
    d_add_more = {(i["id"], j["id"]): 0 for i, j in A_add_more}

    d_new = {}
    for dists in [d, d_add, d_add_more]:
        d_new.update(dists)


    for i in V:
        d_new[(i["id"],dummyNode["id"])]=0
         
    M = 9999
    d_new[(0,dummyNode["id"])] = M

    #print("V_new: ",V_new)
    #print("A_new: ",A_new)
    #print("d_new: ",d_new)
    

    #Gurobi model
    m = Model('COVRP')
    Q = 3
    f = 1000
   

    #decision variables
    x={}
    u={}


    #is path between nodes i and j traversed
    for i in V_new:
        for j in V_new:
            if(i != j):
                x[(i["id"],j["id"])]=m.addVar(vtype=GRB.BINARY, name="x_{}_{}".format(i,j))
            
    #load u after leaving node i
    for i in V_new:
        u[i["id"]]=m.addVar(vtype=GRB.CONTINUOUS, name="u_{}".format(i))

    #amount of paths(vehicles)
    k=m.addVar(vtype=GRB.INTEGER)

    m.update()

    #general constraints
    #no more outgoing arcs from the depot as paths(vehicles)
    m.addConstr(quicksum(x[(kita["id"],i["id"])] for i in I) <= k)

    #no more incomming arcs to the dummy node as paths(vehicles)
    m.addConstr(quicksum(x[(i["id"],dummyNode["id"])] for i in I) <= k)

    #each arc should only be traversed once
    I_d = I + [dummyNode]
    for i in I:
        m.addConstr(quicksum(x[(i["id"],j["id"])] for j in I_d if i != j) == 1)

    for j in I:
        m.addConstr(quicksum(x[(i["id"],j["id"])] for i in V if i != j) == 1)
        
    #capacity constraints after (MTZ) + Kara et al. 2004
    #make sure path(vehicle) capacity is never exceeded
    for i in I:
        for j in I:
            if(i != j):
                m.addConstr(u[i["id"]]-u[j["id"]]+Q*x[(i["id"],j["id"])]+(Q-2)*x[(j["id"],i["id"])] <= Q-1)
                
    #make sure load is not decreasing until destination
    for i in I:
        m.addConstr(u[i["id"]] >= 1)
        
    #make sure path(vehicle) capacity is never exceeded
    for i in I:
        m.addConstr(u[i["id"]]-x[(kita["id"],i["id"])]+Q*x[(kita["id"],i["id"])] <= Q)

    #objective function
    obj = quicksum(x[i["id"],j["id"]] * d_new[(i["id"],j["id"])]
                    for i in V_new
                    for j in V_new if i!= j)
    obj = obj + f*k

    m.setObjective(obj, GRB.MINIMIZE)

    m.Params.MIPGap = 0.1
    m.Params.TimeLimit = 30  # seconds
    m.optimize()


    chosenPaths = []
    for i in V:
        for j in V:
            if i != j:
                if x[(i["id"],j["id"])].x > 0.99:
                    chosenPaths.append((i,j))

    print('\nChosen paths: ',chosenPaths)
    
    #Build tours:
    tours= []

    while(len(chosenPaths) > 0):
        for link in chosenPaths:
            if link[0] == kita:
                tours.append([link])
                chosenPaths.remove(link)
            else:
                for tour in tours:
                    for item in tour:
                        if link[0] == item[1]:
                            tour.append(link)
                            chosenPaths.remove(link)

                            
    print('\nTours: ')
    for tour in tours:
        print("single tour:\n",tour)
    
    result = getAssignements(tours)
    
    #TODO: add driver to respective tour
    formatted_tours=[]

    ordered_drivers=list(result.values())

    #get from list of tuples(links) to a ordered list of objects:
    newTours=[]
    
    for tour in tours:
        ordered_pickups=[]
        k=-1
        for link in tour:
            k=k+1
            if k==0:
                ordered_pickups.append(link[0])
                ordered_pickups.append(link[1])
            else:
                ordered_pickups.append(link[1])
        newTours.append(ordered_pickups)

    print("\nnewTours:",newTours)

    k=-1
    for tour in newTours:
        k=k+1
        formatted_tours.append({"driver":ordered_drivers[k],"pickups":tour})

    

    #TODO: form the results easily displayable tours mit respective pickups and drivers
    # something like: [{"pickups":({child1...},{child2...},...), "driver":{...}}]

    #tours look like: [({link1...},{link2...}),({link1...},{link2...}),...]
    #assignements look like [{tour_endpoint_ID:{driver...}},{tour_endpoint_ID:{driver...}},...]

  


    print("\n formatted tours:")
    for tour in formatted_tours:
        print("\n",tour)
        
    return formatted_tours


def getAssignements(tours):

    #get the location of all vehicles
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    # the openrouteservice api wants long,lat, google Maps for example uses lat,long
    cursor.execute("SELECT * FROM employees")

    res = cursor.fetchall()

    cursor.close()
    cnx.close()    

    drivers = []
    for driver in res:
        drivers.append({"id":driver[0],"name":driver[1],"address":driver[2],"geo":(driver[3],driver[4])})

    #get the endpoints of all tours
    endpoints=[]
    for tour in tours:
        endpoints.append(tour.pop()[1])

    print("endpoints: ",endpoints)
    print("drivers: ",drivers)

    #make an assignment by the shortest path from each vehicle to each endpoint
    nodes = drivers+endpoints
    locations=[]
    for node in nodes:
        locations.append(node["geo"])

    print("locations: ",locations)

    
    indecies=list(range(len(drivers),len(locations)))
    #print("indicies: ",indecies)
    #distance matrix from openrouteservice
    
    url = 'https://api.openrouteservice.org/v2/matrix/driving-car'
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    headers = {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': api_key,
        'Content-Type': 'application/json; charset=utf-8'
    }

    payload = {"locations":locations, "destinations":indecies}

    geo = requests.post(url, json=payload, headers=headers)
    json_response = json.loads(geo.text)

    durations= json_response["durations"]

    print("durations: ",durations)
    
    distances={}
    i=-1
    k=-1

    for vertical in drivers:
        i=i+1
        k=-1
        for horizontal in endpoints:
            k=k+1
            distances.update({(vertical["id"],horizontal["id"]):durations[i][k]})

    
    print("distances: ",distances)
    
    #to all endpoints, assign the nearest vehicle
    assignments = {}
    best = None
    bestNode = None
    #{endpoint1: vehicle, endpoint2: vehicle,... }
    for endpoint in endpoints:
        for driver in drivers:
            if best is None:
                best = distances[(driver["id"],endpoint["id"])] 
            elif distances[(driver["id"],endpoint["id"])] < best:
                best = distances[(driver["id"],endpoint["id"])]
                bestNode = driver
        
        assignments.update({endpoint["id"]:bestNode})

    print("assignments: ", assignments)

    return assignments


def getAssignementsHeuristic(tours):

    #get the location of all vehicles
    cnx = mysql.connector.connect(user='root', database='drk', host='localhost', password='')
    cursor = cnx.cursor()
    # the openrouteservice api wants long,lat, google Maps for example uses lat,long
    cursor.execute("SELECT * FROM employees")

    res = cursor.fetchall()

    cursor.close()
    cnx.close()    

    drivers = []
    for driver in res:
        drivers.append({"id":driver[0],"name":driver[1],"address":driver[2],"geo":(driver[3],driver[4])})

    #get the endpoints of all tours
    
    endpoints=[]
    for tour in tours:
        endpoint = tour.pop()
        #but it back in! we are working with a ref not a copy
        tour.append(endpoint)
        endpoints.append(endpoint)

    print("endpoints: ",endpoints)
    print("drivers: ",drivers)

    #make an assignment by the shortest path from each vehicle to each endpoint
    nodes = drivers+endpoints
    locations=[]
    for node in nodes:
        locations.append(node["geo"])

    print("locations: ",locations)

    
    indecies=list(range(len(drivers),len(locations)))
    #print("indicies: ",indecies)
    #distance matrix from openrouteservice
    
    url = 'https://api.openrouteservice.org/v2/matrix/driving-car'
    api_key="5b3ce3597851110001cf624825df9a8c3f214d7f98fe50bd0811b792"
    headers = {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': api_key,
        'Content-Type': 'application/json; charset=utf-8'
    }

    payload = {"locations":locations, "destinations":indecies}

    geo = requests.post(url, json=payload, headers=headers)
    json_response = json.loads(geo.text)

    durations= json_response["durations"]

    print("durations: ",durations)
    
    distances={}
    i=-1
    k=-1

    for vertical in drivers:
        i=i+1
        k=-1
        for horizontal in endpoints:
            k=k+1
            distances.update({(vertical["id"],horizontal["id"]):durations[i][k]})

    
    print("distances: ",distances)
    
    #to all endpoints, assign the nearest vehicle
    assignments = {}
    best = None
    bestNode = None
    #{endpoint1: vehicle, endpoint2: vehicle,... }
    for endpoint in endpoints:
        for driver in drivers:
            if best is None:
                best = distances[(driver["id"],endpoint["id"])]
                bestNode = driver 
            elif distances[(driver["id"],endpoint["id"])] < best:
                best = distances[(driver["id"],endpoint["id"])]
                bestNode = driver
        
        assignments.update({endpoint["id"]:bestNode})
        #remove driver from available once its assigned
        try:
            drivers.remove(bestNode)
        except ValueError:
            pass
        best = None
        bestNode = None

    print("assignments: ", assignments)

    return assignments

def calctotalDist(tour,distances):
    innerDist = 0
    i=0
    for link in tour:
        try:
            innerDist = innerDist + distances[(link,tour[i+1])]
        except IndexError:
            pass
        i=i+1
        
    return innerDist

def getRoutesHeuristic(nodes,distances,vehicleCapacity):
    '''
    basic approach clark-wright savings algorithm:

    1. calculate saving for all possible node pairs
    2. order descending
    3. start from the list and search through it, build up routes
    4. start over if there are no other link options or if capacity limit is reached 
    
    adjustment to OVRP:
    Sij=C1j-Cij
    '''

    #calc savingsmatrix
    savings={}

    for vertical in nodes:
        for horizontal in nodes:
            if vertical["id"] != horizontal["id"]:
                saving = distances[(0,horizontal["id"])] - distances[(vertical["id"],horizontal["id"])] 
                savings[(vertical["id"],horizontal["id"])] = saving

    #print("savings:\n", savings)

    #order savings

    ordered = {}
    sorted_keys = sorted(savings, key=savings.get,reverse=True)
    for w in sorted_keys:
        ordered[w] = savings[w]

    #print("\n ordered: \n",ordered)

    #clear global helper variables
    global new
    new = ()
    global routes 
    routes = []
    global capacity
    capacity = vehicleCapacity

    #remove the links to the depot:
    newOrdered = {k: v for k, v in ordered.items() if k[0] != 0 and k[1] !=0 }

    assignNode(newOrdered)

    #TODO: check if all nodes are assigned to routes, if no, add the last one as an additional route
    allNodes = [k["id"] for k in nodes if k["id"] != 0]
    #print("available nodes: ",allNodes)

    usedNodes = []
    for node in allNodes:
        temp = [node for tour in routes if node in tour]
        usedNodes = usedNodes + temp

    #print("usedNodes ", usedNodes)
    
    #get diff between between used and available Nodes:
    diff = [node for node in allNodes if node not in usedNodes]
    #print("diff ", diff)

    if len(diff) > 0:
        routes.append(tuple(diff))

    print("\n Final Routes: \n", routes)

    #add the 2opt improvement algorithm
    """
    start new part 
    """
    improvedRoutes= routes.copy()
    for n in range(1):
        run = []
        for tour in improvedRoutes:
            #swap two nodes
            tourList = list(tour)
            best = list(tour).copy()
            bestDist = calctotalDist(tour, distances)
           
            for i in range(len(tour)):
                for k in range(1,len(tour)-1):
                   
                    temp = tourList[k]
                    tourList[k] = tourList[k+1]
                    tourList[k+1] = temp
                    newDist = calctotalDist(tuple(tourList), distances)
                    
                    if(newDist<bestDist):
                        
                        best = tourList.copy()
                        bestDist = newDist
                        
            run.append(tuple(best))
            
        improvedRoutes = run
    

    finalRoutes = improvedRoutes.copy()

    for n in range(1):
        for i in range(len(finalRoutes)):
            for j in range(len(finalRoutes)):
                if(i != j):

                    moreImprovedRoutes = finalRoutes.copy()
                    first = list(moreImprovedRoutes[i]).copy()
                    second = list(moreImprovedRoutes[j]).copy()
                            
                    distFirst = calctotalDist(first, distances)
                    distSecond = calctotalDist(second, distances)
                    totalDist = distFirst + distSecond
                    
                    for k in range(len(first)-1):
                                
                        try:
                            firstTempOne = [first[n] for n in range(k+1)]
                            secondTempOne = [second[n] for n in range(k+1)]
                            firstTempTwo = [first[n] for n in range(k+1,len(first))]
                            secondTempTwo = [second[n] for n in range(k+1,len(second))]
                            
                            newFirst = firstTempOne + secondTempTwo
                            newSecond = secondTempOne + firstTempTwo
                            
                            
                        
                            distFirst = calctotalDist(newFirst, distances)
                            distSecond = calctotalDist(newSecond, distances)
                            newDist = distFirst + distSecond
                
                            if(newDist < totalDist):
                                
                                totalDist = newDist
                                moreImprovedRoutes[i]=tuple(newFirst)
                                moreImprovedRoutes[j] = tuple(newSecond)
       
                                finalRoutes = moreImprovedRoutes
                                break
                                  
                        except IndexError:
        
                            break

    imbaRoutes= finalRoutes.copy()
    for n in range(1):
        run = []
        for tour in imbaRoutes:
            #swap two nodes
            tourList = list(tour)
            best = list(tour).copy()
            bestDist = calctotalDist(tour, distances)
           
            for i in range(len(tour)):
                for k in range(1,len(tour)-1):
                   
                    temp = tourList[k]
                    tourList[k] = tourList[k+1]
                    tourList[k+1] = temp
                    newDist = calctotalDist(tuple(tourList), distances)
                    
                    if(newDist<bestDist):
                        
                        best = tourList.copy()
                        bestDist = newDist
                        
            run.append(tuple(best))
            
        imbaRoutes = run

    print("\n Imba Routes: \n", imbaRoutes)

    """
    end new part
    """

    #now show the the data objects instead of just the IDs
    newRoutes=[]
    for tour in imbaRoutes:
        newTour=[]
        for node in tour:
            for child in nodes:
                if node == child["id"]:
                    newTour.append(child)
        newRoutes.append(newTour)

    #print("Routes with Objects: \n", newRoutes)

    #TODO: now assign the drivers!
    assignments = getAssignementsHeuristic(newRoutes)

    ordered_drivers=list(assignments.values())

   

    formatted_tours=[]
    k=-1
    for tour in newRoutes:
        k=k+1
        formatted_tours.append({"driver":ordered_drivers[k],"pickups":tour})

    #print("formatted_tours: \n", formatted_tours)
    

    return formatted_tours



def assignNode(savings):
    global new
    print("new: ",new)
    global routes
    print("routes: ",routes)
    global capacity
   

    newSavings=savings
    
    for key in savings:
        #print("inbetween:\n",routes)
        #print("newSavings: ", [k for k, v in savings.items()])

            

        if len(new) >= capacity:
            routes.append(new)
            #delete all links that contain any node of this tour

            newSavings = {k: v for k, v in newSavings.items() if k[0] not in new and k[1] not in new}

            new=()
            break;
            
            

        if len(new) == 0:
            new = key
                #remove key from savings
            try:
                del newSavings[key]
                del newSavings[(key[1],key[0])]
            except KeyError:
                pass
                #remove keys where this[0] == other[0]
            newSavings = {k: v for k, v in newSavings.items() if k[0]!=key[0]}
                #remove keys where this[1] == other[1] 
            newSavings = {k: v for k, v in newSavings.items() if k[1]!=key[1]}
                #start all over
            break;
        elif key[0] == new[len(new)-1] and key[1] not in new:
            new = new + (key[1],)
                #remove key from savings
            newSavings = savings
            try:
                del newSavings[key]
                del newSavings[(new[len(new)-1],new[0])]
            except KeyError:
                pass
                #remove all keys that contain this[0]
            newSavings = {k: v for k, v in newSavings.items() if k[0] != key[0] and k[1] != key[0]}
                #remove all keys where other[1] == this[1]
            newSavings = {k: v for k, v in newSavings.items() if k[1]!=key[1]}
                #start all over
            break;
        elif key[1] == new[0] and key[0] not in new:
            new = (key[0],) + new
                #remove key from savings
            newSavings = savings
            try:
                del newSavings[key]
                del newSavings[(new[0],new[len(new)-1])]
            except KeyError:
                pass
                #remove all keys that contain this[1]
            newSavings = {k: v for k, v in newSavings.items() if k[0] != key[0] and k[1] != key[0]}
                #remove all keys where other[0] == this[0]
            newSavings = {k: v for k, v in newSavings.items() if k[1]!=key[1]}
                #start all over
            break;
        
        
        
        


    if(len(newSavings) >= 1):
        assignNode(newSavings)
    else:
        print("else case reached!")
        if len(new)>0:
            routes.append(new)
        
   

    return


