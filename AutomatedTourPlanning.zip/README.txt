TODO:
change API KEY to routing.py and main.py for openroute Service to you personal KEY you obtain at https://openrouteservice.org/

INSTALL:
Install Python (I use Anaconda)
Install Flask
    When using Anaconda, you can install Flask by executing "conda install -c anaconda flask" 
Install libraries ([pip install] mysql-connector-python, folium, openrouteservice)
Install MySQL (with XAMPP for example)

DB:
create DB "drk"
create tables (or import drk.sql in files):
1. customer(id[int], name[text], address[text], longitude[float], latitude[float], active[int], comment[text])
2. empoyees(id[int], name[text], address[text], longitude[float], latitude[float], active[int], comment[text])


RUN(in Anaconda Prompt):
1) Navigate to the project folder
2) Use command: set FLASK_APP=main.py
3) Use command: flask run